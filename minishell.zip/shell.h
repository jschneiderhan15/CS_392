/*******************************************************************************
 * Name        : shell.h
 * Author      : Jack Schneiderhan and Cindy Zhang
 * Date        : April 11th 2021
 * Description : Permission File.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/

#ifndef perms_h_
#define perms_h_

int parseArgs(char* input, char** argv);

#endif
